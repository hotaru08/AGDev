Player1 = 0.000000
Player2 = 100

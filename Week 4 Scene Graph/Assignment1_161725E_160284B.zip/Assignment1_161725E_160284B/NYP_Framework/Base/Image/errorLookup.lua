error100 = "This is not a table."
error101 = "This is not a valid Waypoint coordinate."